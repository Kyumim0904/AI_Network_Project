
# 연구 노트

## 주요 작업 내용
- VirtualBox와 Xshell을 활용한 환경 설정.
- Python 기반의 Flask 앱 개발.
- RAG 기법과 Vectorstore를 활용한 AI 응답 생성.

## 설치 및 실행
- 자세한 설치 가이드는 [README.md](../README.md) 파일을 참조하세요.
